package com.example.myapplication

import android.widget.ImageView

data class ProductModel(
    var proId: String? = null,
    var proName: String? = null,
    var proPrice: String? = null,
    var proLoc: String? = null,
    var proDesc: String? = null,
    var number: String? = null,
    var proUrl: String? = null

)